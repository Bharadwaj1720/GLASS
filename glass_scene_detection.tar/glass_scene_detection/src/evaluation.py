import torch
import torch.nn as nn
from torchvision import datasets, models
from torch.utils.data import DataLoader, random_split
from transforms_config import get_data_transforms
from utils import evaluate_model
import os

if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    dataset_dir = 'data/CombinedDataset'
    data_transforms = get_data_transforms()
    full_dataset = datasets.ImageFolder(dataset_dir, transform=data_transforms['train'])

    dataset_size = len(full_dataset)
    train_size = int(0.8 * dataset_size)
    val_size = int(0.1 * dataset_size)
    test_size = dataset_size - train_size - val_size

    train_dataset, val_dataset, test_dataset = random_split(full_dataset, [train_size, val_size, test_size], generator=torch.Generator())
    val_dataset.dataset.transform = data_transforms['val']
    test_dataset.dataset.transform = data_transforms['test']

    batch_size = 32
    dataloaders = {
        'train': DataLoader(train_dataset, batch_size=batch_size, shuffle=True),
        'val': DataLoader(val_dataset, batch_size=batch_size, shuffle=False),
        'test': DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    }

    dataset_sizes = {x: len(dataloaders[x].dataset) for x in ['train', 'val', 'test']}

    #Loading best model weights
    model_path = 'resnet50_exp3_unfrozen_best.pth'
    if not os.path.exists(model_path):
        print(f"Best model weights not found at {model_path}. Please run training first.")
        exit()

    #Initializing model
    resnet50 = models.resnet50(pretrained=False)

    #Getting the number of classes:
    num_classes = len(full_dataset.classes)
    resnet50.fc = nn.Linear(resnet50.fc.in_features, num_classes)
    resnet50.load_state_dict(torch.load(model_path, map_location=device))
    criterion = nn.CrossEntropyLoss()

    evaluate_model(resnet50, dataloaders['test'], criterion, dataset_sizes, device, model_name="Final_Eval")
