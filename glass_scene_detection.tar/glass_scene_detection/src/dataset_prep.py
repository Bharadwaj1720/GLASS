import os
import shutil

if __name__ == "__main__":
    indoor_dir = 'data/IndoorImages'
    outdoor_dir = 'data/OutdoorImages'
    combined_dir = 'data/CombinedDataset'

    #Checking if combined dataset directory exists
    if not os.path.exists(combined_dir):
        os.makedirs(combined_dir)

    print("Combining indoor and outdoor datasets into one directory...")
    #Copying indoor images
    for class_name in os.listdir(indoor_dir):
        source_class_dir = os.path.join(indoor_dir, class_name)
        target_class_dir = os.path.join(combined_dir, class_name)
        if not os.path.exists(target_class_dir):
            os.makedirs(target_class_dir)
        for img_name in os.listdir(source_class_dir):
            src_img = os.path.join(source_class_dir, img_name)
            dst_img = os.path.join(target_class_dir, img_name)
            shutil.copyfile(src_img, dst_img)

    #Copying outdoor images
    for class_name in os.listdir(outdoor_dir):
        source_class_dir = os.path.join(outdoor_dir, class_name)
        target_class_dir = os.path.join(combined_dir, class_name)
        if not os.path.exists(target_class_dir):
            os.makedirs(target_class_dir)
        for img_name in os.listdir(source_class_dir):
            src_img = os.path.join(source_class_dir, img_name)
            dst_img = os.path.join(target_class_dir, img_name)
            shutil.copyfile(src_img, dst_img)

    print("Combined dataset created successfully at:", combined_dir)
