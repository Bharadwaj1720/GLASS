import os
import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets, models
from torch.utils.data import DataLoader, random_split
from transforms_config import get_data_transforms
from utils import evaluate_model, plot_train_val

def train_model(model, dataloaders, criterion, optimizer, dataset_sizes, device, num_epochs, model_name):

    best_val_loss = float('inf')
    history = {'train_loss': [], 'val_loss': [], 'train_acc': [], 'val_acc': []}

    for epoch in range(1, num_epochs+1):
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        for inputs, labels in dataloaders['train']:
            inputs, labels = inputs.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * inputs.size(0)
            temp, preds = torch.max(outputs, 1)
            correct += (preds == labels).sum().item()
            total += labels.size(0)

        epoch_loss = running_loss / dataset_sizes['train']
        epoch_acc = correct / total
        history['train_loss'].append(epoch_loss)
        history['train_acc'].append(epoch_acc)

        #Validation
        model.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0
        with torch.no_grad():
            for inputs, labels in dataloaders['val']:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                v_loss = criterion(outputs, labels)
                val_loss += v_loss.item() * inputs.size(0)
                temp, preds = torch.max(outputs, 1)
                val_correct += (preds == labels).sum().item()
                val_total += labels.size(0)

        val_epoch_loss = val_loss / dataset_sizes['val']
        val_epoch_acc = val_correct / val_total
        history['val_loss'].append(val_epoch_loss)
        history['val_acc'].append(val_epoch_acc)

        print(f'Epoch {epoch}/{num_epochs} | Train Loss: {epoch_loss:.4f}, Acc: {epoch_acc:.4f} | Val Loss: {val_epoch_loss:.4f}, Acc: {val_epoch_acc:.4f}')

        if val_epoch_loss < best_val_loss:
            best_val_loss = val_epoch_loss
            torch.save(model.state_dict(), f'{model_name}_best.pth')
            print(f"New best model saved at epoch {epoch}.")

    return history

if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    data_transforms = get_data_transforms()

    dataset_dir = 'data/CombinedDataset'
    full_dataset = datasets.ImageFolder(dataset_dir, transform=data_transforms['train'])

    dataset_size = len(full_dataset)
    train_size = int(0.8 * dataset_size)
    val_size = int(0.1 * dataset_size)
    test_size = dataset_size - train_size - val_size

    train_dataset, val_dataset, test_dataset = random_split(full_dataset, [train_size, val_size, test_size], generator=torch.Generator())
    val_dataset.dataset.transform = data_transforms['val']
    test_dataset.dataset.transform = data_transforms['test']

    batch_size = 32
    dataloaders = {
        'train': DataLoader(train_dataset, batch_size=batch_size, shuffle=True),
        'val': DataLoader(val_dataset, batch_size=batch_size, shuffle=False),
        'test': DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    }

    dataset_sizes = {x: len(dataloaders[x].dataset) for x in ['train','val','test']}

    num_classes = len(full_dataset.classes)

    #Using a ResNet50 with Places365 pretraining
    places_checkpoint = 'models/resnet50_places365.pth.tar'
    if not os.path.exists(places_checkpoint):
        raise FileNotFoundError("Places365 pre-trained weights not found.")

    resnet50 = models.resnet50(pretrained=False)
    resnet50.fc = nn.Linear(resnet50.fc.in_features, 365)
    checkpoint = torch.load(places_checkpoint, map_location=device)
    state_dict = {k.replace('module.', ''): v for k, v in checkpoint['state_dict'].items()}
    resnet50.load_state_dict(state_dict)
    resnet50.fc = nn.Linear(resnet50.fc.in_features, num_classes)
    resnet50 = resnet50.to(device)

    for param in resnet50.parameters():
        param.requires_grad = False
    for param in resnet50.fc.parameters():
        param.requires_grad = True

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(resnet50.fc.parameters(), lr=0.001, weight_decay=0.01)

    #Training with frozen layers
    print("Training with frozen layers.")
    history_frozen = train_model(resnet50, dataloaders, criterion, optimizer, dataset_sizes, device, num_epochs=15, model_name='resnet50_frozen')

    # Evaluating
    from utils import evaluate_model
    evaluate_model(resnet50, dataloaders['test'], criterion, dataset_sizes, device, model_name='resnet50_frozen')

    #Unfreezing all layers for fine-tuning
    for param in resnet50.parameters():
        param.requires_grad = True

    print("Fine-tuning all layers.")
    optimizer = optim.AdamW(resnet50.parameters(), lr=1e-4, weight_decay=0.01)
    history_unfrozen = train_model(resnet50, dataloaders, criterion, optimizer, dataset_sizes, device, num_epochs=5, model_name='resnet50_unfrozen')

    #Evaluating again
    evaluate_model(resnet50, dataloaders['test'], criterion, dataset_sizes, device, model_name='resnet50_unfrozen')

    #Plotting results
    from utils import plot_train_val
    print("Plotting training progress.")
    plot_train_val(history_frozen, 'ResNet50 Frozen')
    plot_train_val(history_unfrozen, 'ResNet50 Unfrozen')
