# GLASS: Scene Classification Module

This code file contains code for the scene classification component of the GLASS project. It demonstrates how we combined indoor and outdoor datasets, applied data augmentation, leveraged domain-specific pretraining (Places365), and progressively fine-tuned models.

## Setup

1. **Install Requirements:**
   ```bash
   pip install -r requirements.txt
2. **Prepare Data:**  
- Place the indoor dataset in `data/IndoorImages/`.  
- Place the outdoor dataset in `data/OutdoorImages/`.
  
  To reduce the overall size, I am omitting the dataset.
3. **Combine Datasets:**  
Run: `python src/dataset_prep.py`
This script merges indoor and outdoor images into `data/CombinedDataset`, creating a unified set of scene categories.

4. **Download Pretrained Models:**  
Obtain `resnet50_places365.pth.tar` from the Places365 website and place it in `models/`. This model provides domain-specific features for scene classification.

5. **Training and Fine-Tuning:**  
Run: `python src/train_scene_classification.py`

This will:
- Load the combined dataset.  
- Apply data augmentations and splits (train/val/test).  
- Train a ResNet50 model initially with frozen layers (using Places365 weights).  
- Evaluate and then fine-tune by unfreezing layers.  
- Save the best model weights.

6. **Evaluation:**  
After training completes, you can evaluate the best model:
`python src/evaluation.py`

This loads the best weights and prints test performance metrics.

## Acknowledgments

### Datasets:
- Indoor Scene Recognition (MIT Indoor) dataset.  
- Outdoor images scraped from open-image sources (e.g., Unsplash, Pexels).

### Pretrained Models:
- Places365 weights: Acknowledging the authors and contributors of Places365.

### Frameworks:
- PyTorch and torchvision for deep learning models.
